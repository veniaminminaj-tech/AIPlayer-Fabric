package dev.aiplayer;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import dev.aiplayer.entity.AIPlayerEntities;
import dev.aiplayer.entity.AIPlayerEntity;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3730;

public final class AIPlayerCommands {
    private AIPlayerCommands() {}

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
                registerCommands(dispatcher));
    }

    private static void registerCommands(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("spawnai")
                .requires(class_2170.method_71774(class_2170.field_31840))
                .executes(context -> spawn(context.getSource(), AIPlayerConfig.get().botName))
                .then(class_2170.method_9244("name", StringArgumentType.word())
                        .executes(context -> spawn(context.getSource(),
                                StringArgumentType.getString(context, "name")))));
        dispatcher.register(class_2170.method_9247("aiclear")
                .executes(context -> {
                    var source = context.getSource();
                    var player = source.method_44023();
                    if (player == null) {
                        source.method_9213(class_2561.method_43470("This command can only be used by a player."));
                        return 0;
                    }
                    AIPlayerChat.clearMemory(player.method_5667());
                    source.method_9226(() -> class_2561.method_43470("Your AI companion conversation memory was cleared."), false);
                    return 1;
                }));
    }

    private static int spawn(class_2168 source, String name) {
        class_3218 level = source.method_9225();
        class_243 pos = source.method_9222();
        AIPlayerEntity bot = AIPlayerEntities.AI_PLAYER.method_5883(level, class_3730.field_16462);
        if (bot == null) {
            source.method_9213(class_2561.method_43470("Could not create AI player."));
            return 0;
        }
        String safeName = name == null || name.isBlank() ? "AI Player" : name.substring(0, Math.min(32, name.length()));
        bot.method_5665(class_2561.method_43470(safeName));
        bot.method_5880(true);
        bot.method_5814(pos.field_1352, pos.field_1351, pos.field_1350);
        bot.method_36456(source.method_9210().field_1342);
        bot.method_36457(0.0F);
        if (!level.method_8649(bot)) {
            source.method_9213(class_2561.method_43470("Could not spawn AI companion at this location."));
            return 0;
        }
        source.method_9226(() -> class_2561.method_43470("Spawned AI companion: " + safeName), false);
        return 1;
    }
}
