package dev.aiplayer.entity;

import dev.aiplayer.AIPlayerMod;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public final class AIPlayerEntities {
    public static final class_5321<class_1299<?>> AI_PLAYER_KEY = class_5321.method_29179(
            class_7924.field_41266,
            class_2960.method_60655(AIPlayerMod.MOD_ID, "ai_player")
    );

    public static final class_1299<AIPlayerEntity> AI_PLAYER = class_2378.method_10230(
            class_7923.field_41177,
            class_2960.method_60655(AIPlayerMod.MOD_ID, "ai_player"),
            class_1299.class_1300.method_5903(AIPlayerEntity::new, class_1311.field_6294)
                    .method_17687(0.6F, 1.8F)
                    .method_5905(AI_PLAYER_KEY)
    );

    private AIPlayerEntities() {}
}
