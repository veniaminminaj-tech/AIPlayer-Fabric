package dev.aiplayer.entity;

import dev.aiplayer.AIPlayerConfig;
import java.util.EnumSet;
import java.util.UUID;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1314;
import net.minecraft.class_1338;
import net.minecraft.class_1347;
import net.minecraft.class_1352;
import net.minecraft.class_1361;
import net.minecraft.class_1374;
import net.minecraft.class_1376;
import net.minecraft.class_1394;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_5132;
import net.minecraft.class_5134;

public final class AIPlayerEntity extends class_1314 {
    private static final String OWNER_TAG_PREFIX = "aiplayer_owner_";

    public AIPlayerEntity(class_1299<? extends class_1314> type, class_1937 level) {
        super(type, level);
        method_5665(class_2561.method_43470(AIPlayerConfig.get().botName));
        method_5880(true);
        method_5971();
    }

    public static class_5132.class_5133 createAttributes() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 20.0)
                .method_26868(class_5134.field_23719, 0.28)
                .method_26868(class_5134.field_23717, 32.0)
                .method_26868(class_5134.field_23718, 0.15);
    }

    @Override
    protected void method_5959() {
        field_6201.method_6277(0, new class_1347(this));
        field_6201.method_6277(1, new class_1374(this, 1.45));
        field_6201.method_6277(2, new class_1338<>(this, class_1588.class, 10.0F, 1.15, 1.45));
        field_6201.method_6277(3, new FollowNearbyPlayerGoal(this, 1.12));
        field_6201.method_6277(4, new class_1394(this, 1.0));
        field_6201.method_6277(5, new class_1361(this, class_1657.class, 8.0F));
        field_6201.method_6277(6, new class_1376(this));
    }

    private static final class FollowNearbyPlayerGoal extends class_1352 {
        private final AIPlayerEntity mob;
        private final double speed;
        private class_1657 target;

        private FollowNearbyPlayerGoal(AIPlayerEntity mob, double speed) {
            this.mob = mob;
            this.speed = speed;
            method_6265(EnumSet.of(class_1352.class_4134.field_18405));
        }

        @Override
        public boolean method_6264() {
            target = findTarget();
            return target != null && target.method_5805() && mob.method_5858(target) > 6.25;
        }

        @Override
        public boolean method_6266() {
            return target != null && target.method_5805()
                    && mob.method_5858(target) > 6.25
                    && mob.method_5858(target) < 256.0;
        }

        @Override
        public void method_6268() {
            if (target != null) mob.method_5942().method_6335(target, speed);
        }

        @Override
        public void method_6270() {
            mob.method_5942().method_6340();
            target = null;
        }

        private class_1657 findTarget() {
            for (String tag : mob.method_5752()) {
                if (!tag.startsWith(OWNER_TAG_PREFIX)) continue;
                try {
                    UUID ownerId = UUID.fromString(tag.substring(OWNER_TAG_PREFIX.length()));
                    if (mob.method_73183() instanceof class_3218 serverLevel) {
                        class_1657 owner = serverLevel.method_18470(ownerId);
                        if (owner != null) return owner;
                    }
                } catch (IllegalArgumentException ignored) {
                    // Ignore malformed ownership tags.
                }
            }
            return mob.method_73183().method_18460(mob, 16.0);
        }
    }
}
