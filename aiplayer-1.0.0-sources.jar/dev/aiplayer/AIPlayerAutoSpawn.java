package dev.aiplayer;

import dev.aiplayer.entity.AIPlayerEntities;
import dev.aiplayer.entity.AIPlayerEntity;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1297;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.server.MinecraftServer;

public final class AIPlayerAutoSpawn {
    private static final String PLAYER_MARKER = "aiplayer_companion_created";
    private AIPlayerAutoSpawn() {}

    public static void register() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) ->
                spawnForPlayer(server, handler.method_32311()));
    }

    private static void spawnForPlayer(MinecraftServer server, class_3222 player) {
        String ownerTag = "aiplayer_owner_" + player.method_5667().toString();
        if (player.method_5752().contains(PLAYER_MARKER)) return;

        // Migrate worlds where a companion already exists but the player marker was not yet saved.
        for (class_3218 existingLevel : server.method_3738()) {
            for (class_1297 entity : existingLevel.method_27909()) {
                if (entity instanceof AIPlayerEntity && entity.method_5752().contains(ownerTag)) {
                    player.method_5780(PLAYER_MARKER);
                    return;
                }
            }
        }

        class_3218 level = (class_3218) player.method_51469();
        AIPlayerEntity companion = AIPlayerEntities.AI_PLAYER.method_5883(level, class_3730.field_16462);
        if (companion == null) {
            AIPlayerMod.LOGGER.error("Could not create an automatic AI companion for {}",
                    player.method_5477().getString());
            return;
        }

        String configuredName = AIPlayerConfig.get().botName;
        String name = configuredName == null || configuredName.isBlank() ? "AI Player" : configuredName;
        companion.method_5665(class_2561.method_43470(name));
        companion.method_5880(true);
        companion.method_5780(ownerTag);
        companion.method_5814(player.method_23317() + 2.0, player.method_23318(), player.method_23321() + 1.0);
        companion.method_36456(player.method_36454());
        companion.method_36457(0.0F);

        if (level.method_8649(companion)) {
            player.method_5780(PLAYER_MARKER);
            player.method_64398(class_2561.method_43470(name + " joined your world as your AI companion."));
            AIPlayerMod.LOGGER.info("Automatically spawned AI companion for {} in game mode {}",
                    player.method_5477().getString(), player.field_13974.method_14257());
        }
    }
}
