package dev.aiplayer.client;

import dev.aiplayer.AIPlayerConfig;
import dev.aiplayer.AIPlayerMod;
import dev.aiplayer.entity.AIPlayerEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_5619;

public final class AIPlayerClient implements ClientModInitializer {
    private static class_304 openSettings;

    @Override
    public void onInitializeClient() {
        AIPlayerConfig.ensurePlayerFolder();
        class_304.class_11900 category = class_304.class_11900.method_74698(
                class_2960.method_60655(AIPlayerMod.MOD_ID, "general"));
        openSettings = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.aiplayer.open_settings",
                class_3675.class_307.field_1668,
                class_3675.field_32027,
                category
        ));

        class_5619.method_32173(AIPlayerEntities.AI_PLAYER, AIPlayerRenderer::new);

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openSettings.method_1436()) {
                class_310.method_1551().method_1507(new AISettingsScreen());
            }
        });
    }
}
