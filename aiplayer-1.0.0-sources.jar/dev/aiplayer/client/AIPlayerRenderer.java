package dev.aiplayer.client;

import dev.aiplayer.AIPlayerConfig;
import dev.aiplayer.entity.AIPlayerEntity;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import net.minecraft.class_10034;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_1060;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5602;
import net.minecraft.class_5617;
import net.minecraft.class_572;
import net.minecraft.class_909;

public final class AIPlayerRenderer extends class_909<AIPlayerEntity, class_10034, class_572<class_10034>> {
    private static final class_2960 STEVE = class_2960.method_60656("textures/entity/player/wide/steve.png");
    private static final class_2960 ALEX = class_2960.method_60656("textures/entity/player/slim/alex.png");
    private static final class_2960 CUSTOM = class_2960.method_60655("aiplayer", "textures/custom_player_skin");
    private static boolean customSkinLoaded;

    public AIPlayerRenderer(class_5617.class_5618 context) {
        super(context, new class_572<>(context.method_32167(class_5602.field_27577)), 0.5F);
    }

    @Override
    public class_10034 method_55269() {
        return new class_10034();
    }

    @Override
    public class_2960 getTextureLocation(class_10034 state) {
        class_2960 custom = loadCustomSkin();
        if (custom != null) return custom;
        return "alex".equalsIgnoreCase(AIPlayerConfig.get().skin) ? ALEX : STEVE;
    }

    private static class_2960 loadCustomSkin() {
        if (customSkinLoaded) {
            class_1060 manager = class_310.method_1551().method_1531();
            return manager.method_4619(CUSTOM) == null ? null : CUSTOM;
        }
        customSkinLoaded = true;
        Path skinPath = AIPlayerConfig.SKIN_FILE;
        if (!Files.isRegularFile(skinPath)) return null;
        try (InputStream input = Files.newInputStream(skinPath)) {
            class_1011 image = class_1011.method_4309(input);
            if (image.method_4307() != 64 || image.method_4323() != 64) {
                image.close();
                AIPlayerModLog.warn("Custom skin must be a 64x64 PNG: " + skinPath);
                return null;
            }
            class_1043 texture = new class_1043(() -> "AI Player custom skin", image);
            class_310.method_1551().method_1531().method_4616(CUSTOM, texture);
            return CUSTOM;
        } catch (Exception e) {
            AIPlayerModLog.warn("Could not load custom skin PNG: " + e.getMessage());
            return null;
        }
    }

    private static final class AIPlayerModLog {
        private static void warn(String message) {
            dev.aiplayer.AIPlayerMod.LOGGER.warn(message);
        }
    }
}
