package dev.aiplayer.client;

import dev.aiplayer.AIPlayerConfig;
import dev.aiplayer.AIPlayerMod;
import dev.aiplayer.AIProviderClient;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public final class AISettingsScreen extends class_437 {
    private static final List<String> PROVIDERS = List.of("Gemini", "OpenRouter", "DeepSeek", "OpenAI");
    private int providerIndex;
    private class_342 modelBox;
    private class_342 endpointBox;
    private class_342 nameBox;
    private class_342 personalityBox;
    private String status = "API key: .minecraft/ai-playerv/api-key.txt";
    private int statusColor = 0xA0E0A0;

    public AISettingsScreen() {
        super(class_2561.method_43470("AI Player Settings"));
    }

    @Override
    protected void method_25426() {
        AIPlayerConfig config = AIPlayerConfig.get();
        providerIndex = Math.max(0, PROVIDERS.indexOf(config.provider));

        int center = this.field_22789 / 2;
        int left = center - 150;
        int y = Math.max(38, this.field_22790 / 2 - 120);

        method_37063(class_4185.method_46430(providerLabel(), button -> {
            providerIndex = (providerIndex + 1) % PROVIDERS.size();
            button.method_25355(providerLabel());
            String provider = PROVIDERS.get(providerIndex);
            modelBox.method_1852(AIPlayerConfig.defaultModel(provider));
            endpointBox.method_1852(AIPlayerConfig.defaultEndpoint(provider));
            status = "Provider preset changed. API key is read from ai-playerv/api-key.txt.";
        }).method_46434(left, y, 300, 20).method_46431());

        y += 25;
        modelBox = field(left, y, "Model ID", config.model, 128);
        y += 25;
        endpointBox = field(left, y, "HTTPS API endpoint URL", config.endpoint, 512);
        y += 25;
        nameBox = field(left, y, "Companion name", config.botName, 32);
        y += 25;
        personalityBox = field(left, y, "Personality", config.personality, 180);

        y += 30;
        method_37063(class_4185.method_46430(class_2561.method_43470("Save settings"), button -> save())
                .method_46434(left, y, 145, 20).method_46431());
        method_37063(class_4185.method_46430(class_2561.method_43470("Test connection"), button -> testConnection())
                .method_46434(left + 155, y, 145, 20).method_46431());

        y += 25;
        method_37063(class_4185.method_46430(class_2561.method_43470("Done"), button -> method_25419())
                .method_46434(left, y, 300, 20).method_46431());
    }

    private class_342 field(int x, int y, String hint, String value, int maxLength) {
        class_342 box = new class_342(field_22793, x, y, 300, 20, class_2561.method_43470(hint));
        box.method_1880(maxLength);
        box.method_1852(value == null ? "" : value);
        box.method_47404(class_2561.method_43470(hint));
        method_37063(box);
        return box;
    }

    private class_2561 providerLabel() {
        return class_2561.method_43470("Provider: " + PROVIDERS.get(providerIndex) + "  (click to change)");
    }

    private void save() {
        AIPlayerConfig config = AIPlayerConfig.get();
        config.provider = PROVIDERS.get(providerIndex);
        config.model = modelBox.method_1882().trim();
        config.endpoint = endpointBox.method_1882().trim();
        config.botName = nameBox.method_1882().trim().isEmpty() ? "AI Player" : nameBox.method_1882().trim();
        config.personality = personalityBox.method_1882().trim().isEmpty()
                ? "Friendly, curious, helpful, and knowledgeable about Minecraft."
                : personalityBox.method_1882().trim();
        try {
            AIPlayerConfig.save();
            status = "Saved. API key: .minecraft/ai-playerv/api-key.txt";
            statusColor = 0x80E0A0;
        } catch (Exception e) {
            status = "Save failed: " + e.getMessage();
            statusColor = 0xFF8080;
            AIPlayerMod.LOGGER.error("Could not save AI settings.", e);
        }
    }

    private void testConnection() {
        save();
        if (status.startsWith("Save failed")) return;
        status = "Testing provider connection...";
        statusColor = 0xFFFF80;
        AIProviderClient.ask("Reply with exactly: connection successful")
                .whenComplete((reply, error) -> class_310.method_1551().execute(() -> {
                    if (error != null) {
                        status = "Connection failed: " + error.getMessage();
                        statusColor = 0xFF8080;
                    } else {
                        status = "Connected successfully.";
                        statusColor = 0x80E0A0;
                    }
                }));
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float delta) {
        method_25420(graphics, mouseX, mouseY, delta);
        super.method_25394(graphics, mouseX, mouseY, delta);
        graphics.method_27534(field_22793, field_22785, field_22789 / 2, 18, 0xFFFFFF);
        graphics.method_25300(field_22793, status, field_22789 / 2, field_22790 - 28, statusColor);
        graphics.method_25300(field_22793, "M: settings | Skin PNG: .minecraft/ai-playerv/skin.png", field_22789 / 2, field_22790 - 14, 0xAAAAAA);
    }

    @Override
    public void method_25419() {
        class_310.method_1551().method_1507(null);
    }
}
